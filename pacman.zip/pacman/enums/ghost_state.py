from enum import Enum


class GhostState(Enum):
    IDLE = 1
    LEAVING_HOME = 2
    ACTIVE = 3
    DEAD = 4

# use it
