
class Units:
    Milliseconds = 1
    Seconds = 2
