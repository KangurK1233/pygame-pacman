from enum import Enum


class GhostMode(Enum):
    CHASE = 1
    SCATTER = 2
    FRIGHTENED = 3
