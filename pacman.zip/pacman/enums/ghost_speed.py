from enum import Enum


class GhostSpeed(Enum):
    NORMAL = 1
    FRIGHT = 2
    TUNNEL = 3
