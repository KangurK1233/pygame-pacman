from enum import Enum


class PacmanSpeed(Enum):
    NORMAL = 1
    NORMAL_DOTS = 2
    FRIGHT = 3
    FRIGHT_DOTS = 4