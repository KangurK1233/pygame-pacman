from stages.menu_stage import MenuStage
from stages.stage import StageUpdateType


class StartMenuStage(MenuStage):
    START_BUTTON = "ALUSTA"
    QUIT_BUTTON = "VÄLJU"

    def __init__(self):
        super().__init__()

    def _add_buttons(self):
        self._add_button(self.START_BUTTON, self._start_game_clicked)
        self._add_button(self.QUIT_BUTTON, self._quit_clicked)

    def _start_game_clicked(self):
        self.notify(StageUpdateType.RESTART)

    def _quit_clicked(self):
        self.notify(StageUpdateType.QUIT)
